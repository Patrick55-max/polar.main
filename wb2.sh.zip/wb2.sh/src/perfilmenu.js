const perfilmenu = (prefix, pushname) => {
    return `༺《 🪐 Albion bot 🪐 》༻

🪐 Menu Perfil 🪐

☀ ⸢ ${prefix}setnameuser ⸥ ☀
☀ ⸢ ${prefix}setidade ⸥ ☀
☀ ⸢ ${prefix}setdesc ⸥ ☀



Todos os comandos acima necessitam que voce esteja registrado!

digite ${prefix}menu para mais comandos                                                                     
  `



}

exports.perfilmenu = perfilmenu
