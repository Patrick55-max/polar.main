const regras_bonde = (prefix, namebot) => {
	return `
*Regras para adcionar o ${namebot} em seu Bonde*\n
     *O Bonde/projeto QUE SOLICITAR A PRESENÇA DO  ${namebot}, DEVERÁ SEGUIR DE ACORDO COM SUAS DIRETRIZES*, CASO CONTRÁRIO O BOT NÃO FICARÁ

             *_SENDO DIRETRIZES DO ${namebot}_*

 ◆➤ 🔰 1 CRIAR INTERAÇÃO ENTRES OS USUÁRIOS do Bonde/projeto ATRAVES DO LEVEL 

 ◆➤ 🔰 2 não saia da central de comando sem ser levelcom 45

 ◆➤ 🔰 3 *nunca derespeite outro menbro independente de sua ações pessoais*

       *_SENDO REGRAS PRA ADICIONAR O ${namebot} EM GRUPO_* 


 ◆➤ 🔰 1 Entre na  central e mande o link no pv do ${namebot} 

 ◆➤ 🔰 2 DEVERÁ ESTÁ É PERMANECE NO GRUPO DE CONTROLE (Digite ${prefix}gpof )

 ◆➤ 🔰 3 *O GRUPO A QUAL E PRETENDIDO ADICIONAR O ${namebot} DEVE ESTAR COM MAIS DE 10 PARTICIPANTES* 

 ◆➤ SE VOCÊ FOR OU FAZER PARTE DA ORGANIZAÇÃO DE BONDES/PROJETO DIGITE ${prefix}regras_bonde
`
}

exports.regras_bonde = regras_bonde
