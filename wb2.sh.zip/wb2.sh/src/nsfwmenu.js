const nsfwmenu = (prefix, pushname) => {
    return `༺《 🪐 Albion bot 🪐 》༻

🪐 Menu nsfw 🪐

☀ ⸢ ${prefix}nsfwbobs ⸥ ☀
☀ ⸢ ${prefix}randomgentaio ⸥ ☀
☀ ⸢ ${prefix}nsfwsidebobs ⸥ ☀
☀ ⸢ ${prefix}nsfwahegao ⸥ ☀
☀ ⸢ ${prefix}nsfwthighs ⸥ ☀
☀ ⸢ ${prefix}nsfwarmpits ⸥ ☀
☀ ⸢ ${prefix}hentai ⸥ ☀

Todos os comandos acima necessitam que o nsfw esteja ativo

digite ${prefix}menu para mais comandos                                                                     
  `



}

exports.nsfwmenu = nsfwmenu
