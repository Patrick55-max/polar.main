const regras_add = (prefix, namebot) => {
	return `
*Regras para adcionar o ${namebot} em seu Grupo*\n
     *O GRUPO QUE SOLICITAR A PRESENÇA DO BOT ALBION, DEVERÁ SEGUIR DE ACORDO COM SUAS DIRETRIZES*, CASO CONTRÁRIO O BOT NÃO FICARÁ

*_SENDO DIRETRIZES DO BOT_*

 ◆➤ 🔰 1 CRIAR INTERAÇÃO ENTRES OS USUÁRIOS ATRAVES DO LEVEL 

 ◆➤ *🔰 2 SEM FLOOD OU É BAN*

 ◆➤ 🔰 3 *TER RESPEITO E SER RESPEITADO*

       *_SENDO REGRAS PRA ADICIONAR O BOT EM GRUPO_* 

 ◆➤ 🔰 1 Acesse https://sites.google.com/view/albion-desenvolvedor Registre o grupo!

 ◆➤ 🔰 2 SER MAIOR QUE NÍVEL *5*

 ◆➤ 🔰 3 DEVERÁ ESTÁ É PERMANECE NO GRUPO DE CONTROLE (Digite ${prefix}gpof )

 ◆➤ 🔰 4 *O GRUPO A QUAL E PRETENDIDO ADICIONAR O BOT DEVE ESTAR COM MAIS DE 10 PARTICIPANTES* 

 ◆➤ SE VOCÊ FOR OU FAZER PARTE DA ORGANIZAÇÃO DE BONDES/PROJETO DIGITE ${prefix}regras_bonde
`
}

exports.regras_add = regras_add
