const help = (prefix, sender, getLevel,namebot, user, apoia1,  blocked, date, time,nameuser,NomerOwner ) => {

if ( getLevel === undefined){getLevel ='menos que 0'}
if (nameuser === "Desconhecido.") {nameuser = sender.split('@')[0]}
        return `

  ╔═══❖•ೋ° *${namebot}* °ೋ•❖═══╗
   
  ◆➤ Oʟᴀ, ᴛᴜᴅᴏ ʙᴇᴍ? ${nameuser}!
  
       Este sou eu 
       
  ◆➤ Facebook: 
  ◆➤ Insta: 
  ✅ᴜsᴜᴀʀɪᴏs:  ${user.length}
  ❌ᴜsᴜᴀʀɪᴏ ʙʟᴏǫᴜᴇᴀᴅᴏs : ${blocked.length}
     ᴀᴘᴏɪᴀᴅᴏʀᴇs: ${apoia1}

  ──────⊱◈◈◈⊰──────
  
  ᴏs ᴘʀɪɴᴄɪᴘᴀɪs ᴄᴏᴍᴀɴᴅᴏ sᴇᴍ ${prefix}
  
  ↳ ɢʀᴜᴘᴏ ᴅᴏ ʙᴏᴛ
  
  ↳ ᴏ ʙᴏᴛ ᴛᴀ ᴏɴ

 ──────⊱◈◈◈⊰──────
 
   🤖 +ᴍᴇɴᴜ🤖

  ↳ ${prefix}ᴍᴇɴᴜᴀᴅᴍɪɴ
 ↝ (ᴍᴇɴᴜ sᴏᴍᴇɴᴛᴇ ᴘᴀʀᴀ ᴀᴅᴍs)
 
  ↳ ${prefix}ᴘᴇʀғɪʟᴍᴇɴᴜ
 ↝ (sᴇᴜ ᴘᴇʀғɪʟ)
 
  ↳ ${prefix}ɴsғᴡᴍᴇɴᴜ
 ↝ (ᴍᴇɴᴜ +18 ᴀɴᴏs)
 
   ↳ ${prefix}levelcom
 ↝ (informação sobre level )
 
  ↳ ${prefix}menujogos
 ↝ (O nome nem é obvio )
 
  ──────⊱◈◈◈⊰────────────────
  *⚠️ ᴄᴏᴍᴀɴᴅᴏ ᴄᴏᴍ ${prefix} ɴᴏ ɪɴɪᴄɪᴏ!⚠️*
  ──────⊱◈◈◈⊰────────────────
 ◆ᴅɪᴠᴇʀᴄᴀᴏ◆

 ◆➤ ${prefix}sɪᴍɪ
    ↝ (ғᴀʟᴀ ᴄᴏᴍ ᴀ sɪᴍɪ)    
 ◆➤ ${prefix}ɢᴀʏ @ᴜsᴇʀ
    ↝ (ғᴀʟᴀ ᴏ ǫᴜᴀɴᴛᴏ ᴇʟᴇ ᴇ ɢᴀʏ)    
 ◆➤ ${prefix}ɢᴀᴅᴏ @ᴜsᴇʀ
    ↝ (ғᴀʟᴀ ᴏ ǫᴜᴀɴᴛᴏ ᴇʟᴇ(ᴀ) ᴇ ɢᴀᴅᴏ)   
 ◆➤ ${prefix}ɴɪᴠᴇʟɢᴀʏ
    ↝ (ғᴀʟᴀ ᴀ % ᴅᴇ ɢᴀʏ ᴅᴏ ɢʀᴜᴘᴏ)
◆➤ ${prefix}ʙᴜʀʀᴏ 
    ↝ (ғᴀʟᴀ ᴀ % ᴅᴇ ʙᴜʀʀɪᴄᴇ  ᴅᴏ ɢʀᴜᴘᴏ)    
◆➤ ${prefix}ɪɴᴛᴇʀ
    ↝ (ғᴀʟᴀ ᴀ % ᴅᴇ ɪɴᴛᴇʟɪɢᴇɴᴄɪᴀ ᴅᴏ ɢʀᴜᴘᴏ)   
◆➤ ${prefix}ɴɪᴠᴇʟɢᴀᴅᴏ
    ↝ (ғᴀʟᴀ ᴀ % ᴅᴇ ɢᴀᴅᴏ ɴᴏ ɢʀᴜᴘᴏ)
◆➤ ${prefix}travequin
    ↝ (ғᴀʟᴀ ᴀ  sua % )
◆➤ ${prefix}ɴɪveltravequin
    ↝ (ғᴀʟᴀ ᴀ % ᴅᴇ travequin ɴᴏ ɢʀᴜᴘᴏ)
◆➤ ${prefix}lolipo
    ↝ (ғᴀʟᴀ ᴀ sua  % de loli)
◆➤ ${prefix}ɴɪᴠᴇʟloli
    ↝ (ғᴀʟᴀ ᴀ % ᴅᴇ loli ɴᴏ ɢʀᴜᴘᴏ)

    
───────────⊱◈◈◈⊰───────────
 ◆Fᴇʀʀᴀᴍᴇɴᴛᴀs◆

 ◆➤ ${prefix}sᴛɪᴄᴋᴇʀ
    ↝ (ᴠᴏᴄᴇ ᴛᴀɴʙᴇᴍ ᴘᴏᴅᴇ ᴍᴀʀᴄᴀʀ ᴜᴍᴀ ғᴏᴛᴏ/ɢɪғ)
 ◆➤ ${prefix}meuid
    ↝ (caso voçê não saiba seu id use este comando para saber)   
 ◆➤ ${prefix}ᴛᴏɪᴍɢ
    ↝ (ᴄᴏɴᴠᴇʀᴛᴇ ғɪɢᴜʀɪɴʜᴀ ᴇᴍ ɪᴍᴀɢᴇᴍ)    
 ◆➤ ${prefix}ᴛᴏᴍᴘ3
    ↝ (ᴄᴏᴍᴀɴᴅᴏ ᴜsᴀᴅᴏ ᴘᴀʀᴀ ʙᴀɪxᴀʀ ᴍᴜsɪᴄᴀ)    
 ◆➤ ${prefix}ᴏᴡɴᴇʀ
    ↝ (ᴇᴅɪᴛᴏʀ)    
 ◆➤ ${prefix}ʙʟᴏᴄᴋʟɪsᴛ
    ↝ (ʟɪsᴛᴀ ᴅᴇ ᴄᴏɴᴛᴀᴛᴏs ʙʟᴏǫᴜᴇᴀᴅᴏs)    
 ◆➤${prefix}ᴡᴀ.ᴍᴇ { ◆ ᴄʀɪᴀ ʟɪɴᴋ ᴘᴀʀᴀ sᴇᴜ WʜᴀᴛsAᴘᴘ } 
 ◆➤ ${prefix}ʙᴜɢ
    ↝ (ᴅɪɢɪᴛᴇ ɪɴғᴏʀᴍᴀᴄᴀᴏ sᴏʙʀᴇ ᴏ ʙᴜɢ)    
 ◆➤ ${prefix}ᴏᴡɴᴇʀɢʀᴏᴜᴘ
   ↝  (ᴇsᴛᴇ ᴄᴏᴍᴀɴᴅᴏ ᴍᴏsᴛʀᴀ ǫᴜᴇᴍ ᴇ ᴅᴀ ᴘᴏʀʀᴀ ᴛᴏᴅᴀ)
   
──────⊱◈◈◈⊰──────
◆Mɪᴅɪᴀ◆

 ◆➤ ${prefix}ʀᴀɴᴅᴏᴍᴋ
 ◆➤ ${prefix}ʏᴛsᴇᴀʀᴄʜ
──────⊱◈◈◈⊰──────
◆ᴅᴏᴡɴʟᴏᴀᴅs◆

 ◆➤ ${prefix}ɪᴍᴀɢᴇs
 ◆➤ ${prefix}ʏᴛᴍᴘ4
 ◆➤ ${prefix}ᴛɪᴋᴛᴏᴋ

──────⊱◈◈◈⊰──────
◆Sᴏᴍ◆

 
 ◆➤ ${prefix}ᴛᴛs
    ↝ (ʟᴇ ɴᴀ ᴠᴏᴢ ᴅᴏ ɢᴏᴏɢʟᴇ ᴏǫ ᴠᴄ ᴅɪɢɪᴛᴀ)
 ◆➤ ${prefix}ʟᴀɴɢ
    ↝ (ʟɪɢᴜᴀɢᴇᴍ ᴅɪᴘᴏɴɪᴠᴇʟ ᴘᴀʀᴀ ${prefix}ᴛᴛs ʟᴀɴɢ ᴛᴇxᴛᴏ)
──────⊱◈◈◈⊰──────
◆ᴍᴜsɪᴄᴀ◆

 ◆➤ ${prefix}ᴘʟᴀʏ
    ↝ (sᴇʟᴇᴄɪᴏɴᴇ ᴏ ɴᴏᴍᴇ ᴅᴀ ᴍᴜsɪᴄᴀ Ex:${prefix} ᴘʟᴀʏ sᴇᴍᴇᴏɴᴇ ʏᴏᴜ ʟᴏᴠᴇᴅ)

──────⊱◈◈◈⊰──────
◆sᴛᴀʟᴋᴇʀ◆

 ◆➤ ${prefix}ᴛɪᴋᴛᴏᴋsᴛᴀʟᴋ
 ◆➤ ${prefix}ɪɢsᴛᴀʟᴋ
 
──────⊱◈◈◈⊰──────
◆ᴀɴɪᴍᴇs◆
  ◆➤ ${prefix}ᴡᴀɪᴛ
    ↝ (ᴄᴏᴍᴀɴᴅᴏ ᴜsᴀᴅᴏ ᴘᴀʀᴀ ᴇɴᴄᴏɴᴛʀᴀʀ ᴀɴɪᴍᴇ ᴘᴇʟᴀ ғᴏᴛᴏ!)


─────────⊱◈◈◈⊰─────────

◆ ⪔ 🤖ᴄᴏᴍᴏ ᴍᴇ ᴀᴅɪᴄɪᴏɴᴀʀ ᴀᴏ sᴇᴜ ɢʀᴜᴘᴏ? 🤖 ⪔ ◆

   ↳ ᴅɪɢɪᴛᴇ ${prefix}ʀᴇɢʀᴀs_ᴀᴅᴅ
   ↳ ᴅɪɢɪᴛᴇ ${prefix}ʀᴇɢʀᴀs_ʙᴏɴᴅᴇ

─────────⊱◈◈◈⊰─────────

   [ ɴᴜᴍᴇʀᴏ: http://wa.me/${NomerOwner.split('@')[0]}]

─────────⊱◈◈◈⊰─────────

   Time: ${time}
  `
}

exports.help = help
