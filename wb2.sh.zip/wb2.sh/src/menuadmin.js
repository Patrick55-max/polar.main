const menuadmin = (prefix, pushname) => {
 return `༺《 🪐 Albion bot 🪐 》༻

🪐 Menu adm 🪐

☀ ⸢ ${prefix}opengp ⸥ ☀
☀ ⸢ ${prefix}closegp ⸥ ☀
☀ ⸢ ${prefix}setfoto ⸥ ☀
(*enviar foto com legenda ${prefix}menu para altera a foto do grupo*)
☀ ⸢ ${prefix}demote @user ⸥ ☀
☀ ⸢ ${prefix}promote @user ⸥ ☀
☀ ⸢ ${prefix}demote @user ⸥ ☀
☀ ⸢ ${prefix}del ⸥ ☀
 (apaga a mensagem do bot)
☀ ⸢ ${prefix}tagall 《1 a 5》 ⸥ ☀
☀ ⸢ ${prefix}add ⸥ ☀
 (comando bloqueado)
☀ ⸢ ${prefix}albioban ⸥ ☀
 (comando bloqueado)
 ☀ ⸢ ${prefix}desc ⸥ ☀
 (altera a descrição do grupo)
 ☀ ⸢ ${prefix}setnome ⸥ ☀
 (altera a descrição do grupo)
☀ ⸢ ${prefix}welcome 《1》 ⸥ ☀
 (depos de ativo não é possivel desativar)
☀ ⸢ ${prefix}rgt 《0/1》 ⸥ ☀
 (Bloqueia o registro no  grupo)
☀ ⸢ ${prefix}nsfw 《0/1》 ⸥ ☀
☀ ⸢ ${prefix}level 《0/1》 ⸥ ☀
☀ ⸢ ${prefix}simih 《0/1》 ⸥ ☀

Alguns comandos é necessario que o bot seja adm

digite ${prefix}menu para mais comandos
 `


}

exports.menuadmin = menuadmin
